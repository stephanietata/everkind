from html.parser import HTMLParser
from pathlib import Path
import re

root = Path('/Users/rahatronel/Documents/Codex/2026-09-24/can')
source = root / 'work/stitch/stitch_everkind_companion_platform_ui_ux'
out = root / 'outputs'
assets = out / 'assets'

logo = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 60" width="240" height="60" fill="none"><g transform="translate(8, 10)"><path d="M2 34C10 37 30 37 38 34" stroke="#8C4A2F" stroke-width="2.5" stroke-linecap="round"/><path d="M6 14C6 26 12 32 20 32C28 32 34 26 34 14H6Z" stroke="#24272A" stroke-width="2.5" stroke-linejoin="round"/><path d="M34 17C38.5 17 41 20 41 23.5C41 27 38 29 33.5 29" stroke="#24272A" stroke-width="2.2" stroke-linecap="round"/><path d="M16 10C16 6 18 5 18 2M24 9C24 5 26 4 26 1" stroke="#8C4A2F" stroke-width="2" stroke-linecap="round"/></g><text x="64" y="38" font-family="Georgia,serif" font-size="28" font-weight="600" fill="#1A1A1A" letter-spacing="-0.5px">Ever<tspan font-family="Arial,sans-serif" font-weight="400" fill="#8C4A2F">Kind</tspan></text></svg>'''
(assets / 'everkind-editorial-logo.svg').write_text(logo)

pages = {
    'everkind_homepage_meaningful_companionship_for_older_australians': ('index.html', 'EverKind — Meaningful time. Human connection.'),
    'everkind_book_a_trusted_companion_flow': ('booking.html', 'Find a companion — EverKind'),
    'everkind_family_dashboard_peace_of_mind_for_loved_ones': ('family-dashboard.html', 'Family dashboard — EverKind'),
    'everkind_life_stories_digital_keepsake_archive': ('life-stories.html', 'Life Stories — EverKind'),
}

routes = {
    'home': 'index.html',
    'how-it-works': 'index.html#how-it-works',
    'companionship': 'index.html#companionship',
    'life-stories': 'life-stories.html',
    'for-families': 'family-dashboard.html',
    'become-a-companion': 'index.html#become-a-companion',
    'book-a-companion': 'booking.html',
    'family-dashboard': 'family-dashboard.html',
    'login': 'family-dashboard.html',
    'pricing': 'life-stories.html#pricing-section',
    'screening-process': 'index.html#trust-safety',
    'trust-safety': 'index.html#trust-safety',
    'faqs': 'index.html#faqs',
    'about-us': 'index.html#about-us',
    'adelaide-community': 'index.html#about-us',
    'contact-us': 'mailto:hello@everkind.com.au',
    'accessibility': 'index.html#accessibility',
    'privacy-policy': 'index.html#privacy-policy',
    'terms-of-service': 'index.html#terms-of-service',
    'complaints-feedback': 'mailto:hello@everkind.com.au?subject=Feedback%20for%20EverKind',
}

class Images(HTMLParser):
    def __init__(self):
        super().__init__(); self.items=[]
    def handle_starttag(self, tag, attrs):
        if tag == 'img':
            d=dict(attrs)
            if d.get('src'): self.items.append((d['src'], d.get('alt','')))

for folder,(filename,title) in pages.items():
    html=(source/folder/'code.html').read_text()
    html=html.replace('<html class="h-full" lang="en">','<html class="h-full" lang="en-AU">')
    html=re.sub(r'<title>.*?</title>',f'<title>{title}</title>',html,count=1,flags=re.S)
    parser=Images(); parser.feed(html)
    unique=[]
    for src,alt in parser.items:
        if src not in [x[0] for x in unique]: unique.append((src,alt))
    # Replace the remote brand asset with the supplied pack's warm editorial vector wordmark.
    for src,alt in unique:
        if '/aida/' in src and 'aida-public' not in src:
            html=html.replace(src,'assets/everkind-editorial-logo.svg')
    photos=['assets/veranda-companionship.jpg','assets/family-story.jpg','assets/family-story.jpg','assets/companion-sarah.jpg','assets/veranda-companionship.jpg','assets/family-story.jpg','assets/companion-sarah.jpg','assets/veranda-companionship.jpg']
    photo_i=0
    for src,alt in unique:
        if 'aida-public' not in src: continue
        if 'Sarah' in alt or alt == 'Profile': local='assets/companion-sarah.jpg'
        elif folder == 'everkind_family_dashboard_peace_of_mind_for_loved_ones':
            local='assets/family-story.jpg' if photo_i else 'assets/veranda-companionship.jpg'; photo_i+=1
        else:
            local=photos[min(photo_i,len(photos)-1)]; photo_i+=1
        html=html.replace(src,local)
    # Make the Stitch navigation routes usable as a small static multi-page prototype.
    def link(match):
        tag=match.group(0)
        path=re.search(r'\bdata-path="([^"]+)"',tag)
        href=re.search(r'\bhref="[^"]*"',tag)
        if path and path.group(1) in routes and href:
            tag=tag[:href.start()]+f'href="{routes[path.group(1)]}"'+tag[href.end():]
        return tag
    html=re.sub(r'<a\b[^>]*>',link,html)
    if filename=='index.html':
        ids={
            'How EverKind works':'how-it-works',
            "More than a visit. It's meaningful time together.":'companionship',
            'Trust comes first. Always.':'trust-safety',
            'Frequently asked questions':'faqs',
            'Give someone you love the gift of time.':'become-a-companion',
        }
        def add_id(match):
            opening=match.group(1); whole=match.group(0); inner=match.group(2)
            text=re.sub(r'<[^>]+>',' ',inner); text=' '.join(text.split())
            for phrase,anchor in ids.items():
                if phrase.lower() in text.lower() and ' id=' not in opening:
                    return opening+f' id="{anchor}"'+match.group(3)
            return whole
        html=re.sub(r'(<h2\b[^>]*)(>)(.*?)(</h2>)',lambda m:add_id(type('M',(),{'group':lambda self,n: {1:m.group(1),0:m.group(1)+m.group(2)+m.group(3)+m.group(4),2:m.group(3),3:m.group(2)}[n]})()) if False else m.group(0),html,flags=re.S)
        # A small targeted pass attaches real section anchors to the editorial headings.
        for phrase,anchor in ids.items():
            h2=re.compile(r'(<h2\b[^>]*)(>)(?=[\s\S]{0,260}?'+re.escape(phrase)+r')',re.I)
            html,n=h2.subn(lambda m:m.group(1)+f' id="{anchor}"'+m.group(2),html,count=1)
    (out/filename).write_text(html)
