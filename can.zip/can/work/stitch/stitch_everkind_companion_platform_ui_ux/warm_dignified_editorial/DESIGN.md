---
name: Warm Dignified Editorial
colors:
  surface: '#f6fbf5'
  surface-dim: '#d7dbd6'
  surface-bright: '#f6fbf5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f5f0'
  surface-container: '#ebefea'
  surface-container-high: '#e5e9e4'
  surface-container-highest: '#dfe4df'
  on-surface: '#181d1a'
  on-surface-variant: '#53433d'
  inverse-surface: '#2c322e'
  inverse-on-surface: '#edf2ed'
  outline: '#86736c'
  outline-variant: '#d9c2ba'
  surface-tint: '#8f4c31'
  primary: '#6f331a'
  on-primary: '#ffffff'
  primary-container: '#8c4a2f'
  on-primary-container: '#ffc9b5'
  inverse-primary: '#ffb599'
  secondary: '#526350'
  on-secondary: '#ffffff'
  secondary-container: '#d2e5cd'
  on-secondary-container: '#566754'
  tertiary: '#633b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#7f5217'
  on-tertiary-container: '#ffcb92'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbce'
  primary-fixed-dim: '#ffb599'
  on-primary-fixed: '#370e00'
  on-primary-fixed-variant: '#72361c'
  secondary-fixed: '#d5e8d0'
  secondary-fixed-dim: '#b9ccb4'
  on-secondary-fixed: '#101f10'
  on-secondary-fixed-variant: '#3b4b39'
  tertiary-fixed: '#ffddba'
  tertiary-fixed-dim: '#f8bb76'
  on-tertiary-fixed: '#2b1700'
  on-tertiary-fixed-variant: '#663e01'
  background: '#f6fbf5'
  on-background: '#181d1a'
  surface-variant: '#dfe4df'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 3.5rem
    fontWeight: '400'
    lineHeight: 4.25rem
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 2.5rem
    fontWeight: '400'
    lineHeight: 3.125rem
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 2.5rem
    fontWeight: '500'
    lineHeight: 3.25rem
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 2rem
    fontWeight: '500'
    lineHeight: 2.625rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 2rem
    fontWeight: '500'
    lineHeight: 2.75rem
  headline-md-mobile:
    fontFamily: Newsreader
    fontSize: 1.625rem
    fontWeight: '500'
    lineHeight: 2.25rem
  headline-sm:
    fontFamily: Newsreader
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2.125rem
  body-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.375rem
    fontWeight: '400'
    lineHeight: 2.125rem
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '400'
    lineHeight: 2rem
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.875rem
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.625rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: 0.015em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.375rem
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-tablet: 2rem
  gutter-desktop: 2.5rem
  margin: 1.5rem
  margin-tablet: 3rem
  margin-desktop: 5rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 2rem
  space-xl: 3.5rem
---

## Brand & Style

This design system is tailored for an Australian companionship platform connecting older adults with vetted, trusted companions. The visual narrative is dignified, peaceful, and elevated—intentionally rejecting the patronizing tropes of aged care such as sterile institutional teals, medicalized blues, or juvenile pastel palettes. Instead, the design adopts the aesthetic sensibility of a high-end publication or an architectural sanctuary: refined, tactile, grounded, and unmistakably warm.

The design movement blends **Warm Minimalism** with **Editorial Craft**. It relies on generous negative space, deliberate organic palettes reminiscent of the Australian landscape (weathered stone, dried eucalyptus, sun-baked earth), and confident typographic hierarchy. The user interface serves two distinct generations simultaneously: older adults (60–85+) who prioritize clarity, high legibility, and physical ease, and their adult children (35–55) who seek reassuring professionalism, security, and warmth.

Every layout prioritizes dignity and respect over frantic utility. Surfaces are generous, interactions are deliberate and forgiving, and sensory friction is minimized through quiet contrast and unhurried pacing.

## Colors

The palette is rooted in the natural Australian landscape, balancing deep mineral darks with soothing sunlit limestone tones.

- **Primary (`#8C4A2F` — Ochre Terracotta):** A rich, sun-baked earth tone used for focal points, major commitments (primary CTAs), active states, and essential navigational signposts. It exudes warmth and vitality without the anxiety of clinical red or aggressive commercial orange. Meets WCAG AAA contrast against warm surface backdrops.
- **Secondary (`#51624F` — Deep Eucalyptus Sage):** A muted, comforting botanical tone representing safety, nature, and peaceful presence. Utilized for badges, secondary verification highlights, companion tags, and informational accents.
- **Tertiary (`#B88344` — Golden Banksia):** An amber ochre employed sparingly for warm celebrations, verified trust badges, milestones, and gentle decorative accents.
- **Neutral (`#1F2421` — Deep Ironbark Charcoal):** A rich organic black-slate replacing harsh true black (`#000000`). It delivers contrast (exceeding 13:1 on surface grounds) for effortless readability among aging eyes without inducing eye strain.
- **Surface Foundations:**
  - **Base Canvas (`#FAF8F5`):** A serene, warm off-white that eliminates screen glare.
  - **Secondary Surface / Card Base (`#F3EFEA`):** A gentle linen-stone container layer that separates interactive groups cleanly.
  - **Tertiary Surface / Recessed Wells (`#E9E4DC`):** Subtle tactile backgrounds for structured form fields and inset modules.
  - **Border & Stroke Neutral (`#DDD7CD`):** Structural hairline definition ensuring crisp boundaries for older eyes without creating heavy barriers.

## Typography

The typographic hierarchy harmonizes the literary warmth of **Newsreader** with the approachable clarity of **Plus Jakarta Sans**.

- **Editorial Serifs (Newsreader):** Applied to top-level headings, section titles, and quote blocks. Newsreader adds humanity, dignity, and literary prestige, banishing any cold medical feeling. Heading weights remain moderate (400–600) to maintain crisp letterforms.
- **Humanist Sans (Plus Jakarta Sans):** Chosen for its tall x-height, clear optical counters, and open geometric proportions. It ensures effortless scanability for aging eyesight and across variable lighting conditions.
- **Senior-Centric Sizing Safeguards:** 
  - Standard body text never drops below `1.125rem` (18px) for primary copy. 
  - Line height is kept generous (minimum 1.6x to 1.7x) to prevent lines from visually blurring together.
  - Sub-labels and metadata have an absolute floor at `0.875rem` (14px) and always render in semi-bold (`600`) to guarantee high-contrast edge definition.

## Layout & Spacing

The layout is grounded in an unhurried, proportional 12-column responsive fluid grid with strict maximum reading containers (`68ch` max width for editorial and companion bio content).

- **Breakpoint Architecture:**
  - **Mobile (< 768px):** 4-column layout. Margin of `1.5rem` (24px) guarantees touch buffer zones from physical phone edges. Vertical component gaps rely heavily on `space-md` (20px) and `space-lg` (32px) to prevent accidental tap collisions.
  - **Tablet (768px – 1199px):** 8-column layout. Margins scale to `3rem` (48px) with gutters of `2rem` (32px).
  - **Desktop (1200px+):** 12-column layout. Max container pinned at `1280px` to maintain focused visual scope. Canvas margins scale to `5rem` (80px), framing the content in quiet negative space.
- **Physical Touch Target Minimum:** Every interactive surface (toggles, cards, buttons, list rows) possesses an intrinsic touch target of at least `52px × 52px` (surpassing the WCAG 44px standard), accounting for fine-motor tremors or less precise touch inputs.

## Elevation & Depth

To preserve an organic, dignified presence, this design system avoids glossy glassmorphism, heavy skeuomorphism, and floaty drop shadows. Visual depth is established through **Tonal Layering** and **Soft Ambient Occlusion**.

- **Surface Tiers:**
  - **Tier 0 (Canvas):** `#FAF8F5` serves as the foundational backdrop.
  - **Tier 1 (Surface / Cards):** `#FFFFFF` or `#F3EFEA` lifts gently off the canvas, always bounded by a delicate `1px` structural boundary in `#DDD7CD` to provide tactile edge definition.
  - **Tier 2 (Popovers, Modals & Floating Drawers):** Pure `#FFFFFF` surfaces paired with an extra-diffused, warm-tinted shadow (`box-shadow: 0 16px 36px -8px rgba(31, 36, 33, 0.08), 0 4px 12px rgba(31, 36, 33, 0.04)`). The shadow uses the neutral ironbark hue rather than synthetic black, grounding floating overlays warmly.
- **Focus & Selection Depth:** Focused interactive elements receive a sharp 2px offset ring in `#8C4A2F` (Terracotta) accompanied by a 2px outer gap of `#FAF8F5`, creating unambiguous accessibility signposting for keyboard and screen-magnifier navigation.

## Shapes

The shape philosophy balances natural approachability with adult maturity. 

- **Level 2 (Rounded):** Standard elements (buttons, inputs, dropdown triggers) feature a `0.5rem` (8px) radius. Grouped cards and modal containers utilize `1rem` (16px), with hero containers and curated spotlight panels scaling to `1.5rem` (24px).
- **Philosophical Rationale:** Completely sharp corners feel clinical and sharp, while hyper-rounded pill shapes risk appearing juvenile or toy-like. The balanced 8px–16px geometry evokes craftsmanship, bespoke stationary, and handcrafted furniture—familiar, safe, and dignified.

## Components

### Buttons
- **Primary Action:** Solid Ochre Terracotta (`#8C4A2F`) fill with warm ivory text (`#FAF8F5`). Minimum height `56px`. Padding: `0 28px`. Font: `label-lg`. Soft hover transition to a deeper ember (`#743D26`). High contrast, clearly demarcated as the next step.
- **Secondary Action:** Outlined with a sturdy 1.5px stroke in `#8C4A2F` on transparent/canvas background; text in `#8C4A2F`. Hover state fills with a warm whisper of `#8C4A2F` at 8% opacity.
- **Quiet Action / Tertiary:** Deep Ironbark (`#1F2421`) text with an underline offset of `6px` and a minimum touch hit-box of `48px`.

### Cards & Companion Profiles
- **Profile Cards:** Clean white or light sand (`#F3EFEA`) background with 1px `#DDD7CD` border. Ample interior padding (`space-lg` / 32px).
- **Companion Imagery:** Portrayed in warm, uncropped organic frames (12px border radius). Never circular avatar crops; generous portraits celebrate the human expression and build authentic trust.
- **Attributes & Verification:** Accompanied by verification badges pairing deep sage (`#51624F`) and white iconography (e.g., "Police Checked," "First Aid Certified," "WWCC").

### Input Fields & Selectors
- **Input Geometry:** Minimum height `56px` with `1.125rem` text to prevent automatic browser zoom on mobile.
- **Rest State:** Background `#FFFFFF` with a 1.5px crisp border in `#DDD7CD`. 
- **Active / Focused:** 2px stroke in `#8C4A2F` with no layout shift.
- **Labels:** Statically positioned above the input in `label-md` (`#1F2421`). Never use floating or disappearing placeholder labels that challenge cognitive memory.
- **Supporting Help Text:** High-contrast warm muted tone (`#555C56`), placed beneath inputs with direct clarity.

### Checkboxes, Radios & Segment Controls
- **Touch Areas:** Physical tap footprint is `48px × 48px`, while the visible control is `24px × 24px` with a 2px stroke.
- **Checked State:** High-contrast solid fill with crisp internal iconography (minimum 3:1 checkmark contrast).
- **Segmented Selectors:** Large toggle cards (`64px` height) with radio buttons built-in, simplifying schedule selection (e.g., "Morning Tea", "Garden Walk", "Medical Appointment").

### Chips & Filter Tags
- **Base Style:** Subtle `#E9E4DC` surface, `10px` roundedness, `44px` height, `label-sm` weight.
- **Selected State:** Shifts to deep sage `#51624F` with crisp `#FAF8F5` text, signaling active refinement clearly without visual clutter.

### Lists & Activity Logs
- Clean horizontal divisions using `1px` hairlines in `#DDD7CD`.
- Generous vertical row padding (`space-md` to `space-lg`).
- Leading icons/dates set in prominent Newsreader serifs, followed by structured Plus Jakarta Sans body descriptions.