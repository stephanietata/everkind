from pathlib import Path
import re

out=Path('/Users/rahatronel/Documents/Codex/2026-09-24/can/outputs')
pages=['index.html','booking.html','family-dashboard.html','life-stories.html']
nav='''<header class="ek-header">
  <div class="ek-header-main">
    <a class="ek-brand" href="index.html" aria-label="EverKind home"><img src="assets/everkind-logo.png" alt="EverKind — Kindness Close To Home" /></a>
    <div class="ek-local"><span class="ek-local-dot"></span> Proudly starting in South Australia</div>
    <div class="ek-actions">
      <button class="ek-a11y" type="button" data-font-scale aria-label="Increase text size"><span class="ek-a11y-symbol">A+</span><span class="ek-a11y-label">Text size</span></button>
      <a class="ek-login" href="family-dashboard.html">Log in</a>
      <a class="ek-book" href="booking.html">Book a companion <span aria-hidden="true">↗</span></a>
      <button class="ek-menu" type="button" aria-label="Open navigation" aria-expanded="false" aria-controls="everkind-navigation"><span aria-hidden="true">☰</span></button>
    </div>
  </div>
  <nav class="ek-nav" id="everkind-navigation" aria-label="Main navigation"><div class="ek-nav-inner">
    <a href="index.html#how-it-works">How it works</a><a href="index.html#companionship">Companionship</a><a href="life-stories.html">Life Stories</a><a href="family-dashboard.html">For families</a><a href="index.html#become-a-companion">Become a companion</a><a href="index.html#about-us">About us</a>
  </div></nav>
</header>'''
styles='''<style id="everkind-polished-header">
:root{--ek-purple:#7541b0;--ek-purple-deep:#54227f;--ek-yellow:#f1e21c;--ek-ink:#211b27;--ek-paper:#faf8fd;--ek-border:#e5ddee}
html.ek-text-large{font-size:112.5%}html.ek-text-larger{font-size:125%}
.ek-header{position:sticky;top:0;z-index:100;background:rgba(250,248,253,.97);border-bottom:3px solid var(--ek-yellow);box-shadow:0 5px 20px rgba(47,28,66,.08);backdrop-filter:blur(12px)}
.ek-header-main{min-height:75px;max-width:1280px;margin:0 auto;padding:10px 40px;display:flex;align-items:center;gap:28px}
.ek-brand{display:flex;align-items:center;flex:none;border-radius:3px;overflow:hidden}.ek-brand img{display:block;width:auto;height:45px;max-width:min(42vw,178px);object-fit:contain}
.ek-local{margin-left:auto;display:flex;align-items:center;gap:9px;color:#65576f;font:600 12px/1.4 'Plus Jakarta Sans',Arial,sans-serif;white-space:nowrap}.ek-local-dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--ek-yellow);box-shadow:0 0 0 3px rgba(117,65,176,.1)}
.ek-actions{display:flex;align-items:center;gap:12px}.ek-a11y,.ek-login,.ek-book,.ek-menu{min-height:44px;border-radius:8px;font:600 13px/1.2 'Plus Jakarta Sans',Arial,sans-serif;display:inline-flex;align-items:center;justify-content:center;gap:8px;white-space:nowrap;cursor:pointer;text-decoration:none;transition:background .18s,color .18s,border-color .18s,transform .18s}
.ek-a11y{padding:0 13px;background:#f1eaf8;border:1px solid #d8c8e9;color:#48266b}.ek-a11y:hover{background:#e8dcf4}.ek-a11y-symbol{font-weight:700;font-size:15px}.ek-login{padding:0 11px;color:#51475a}.ek-login:hover{text-decoration:underline;text-underline-offset:4px}.ek-book{min-height:48px;padding:0 19px;background:var(--ek-purple-deep);color:#fff;border:1px solid var(--ek-purple-deep);box-shadow:0 2px 5px rgba(52,29,78,.13)}.ek-book:hover{background:#6a369e;transform:translateY(-1px)}.ek-menu{display:none;border:1px solid #d8c8e9;background:#f4eef9;color:#48266b;width:44px;padding:0;font-size:20px}
.ek-nav{border-top:1px solid #eee8f5;background:#fff}.ek-nav-inner{max-width:1280px;min-height:42px;margin:0 auto;padding:0 34px;display:flex;align-items:center;justify-content:center;gap:clamp(18px,3vw,43px)}.ek-nav a{position:relative;min-height:42px;display:inline-flex;align-items:center;color:#554b5d;text-decoration:none;font:600 12px/1.35 'Plus Jakarta Sans',Arial,sans-serif;white-space:nowrap}.ek-nav a:hover,.ek-nav a:focus-visible{color:var(--ek-purple-deep)}.ek-nav a:after{content:"";position:absolute;left:0;right:100%;bottom:7px;height:2px;background:var(--ek-purple);transition:right .18s}.ek-nav a:hover:after,.ek-nav a:focus-visible:after{right:0}
.ek-header a:focus-visible,.ek-header button:focus-visible{outline:3px solid var(--ek-purple);outline-offset:3px}
@media(max-width:1000px){.ek-header-main{padding:9px 24px;gap:16px}.ek-local{font-size:11px}.ek-nav-inner{gap:clamp(13px,2vw,24px)}.ek-nav a{font-size:11px}.ek-book{padding:0 14px}}
@media(max-width:760px){.ek-header-main{min-height:66px;padding:8px 16px;gap:10px}.ek-brand img{height:38px;max-width:39vw}.ek-local,.ek-login{display:none}.ek-actions{margin-left:auto;gap:7px}.ek-a11y{width:42px;min-height:42px;padding:0}.ek-a11y-label{display:none}.ek-book{min-height:42px;padding:0 11px;font-size:11px;gap:6px}.ek-menu{display:inline-flex;min-height:42px}.ek-nav{display:none;border-top:1px solid var(--ek-border)}.ek-nav.is-open{display:block}.ek-nav-inner{display:flex;flex-direction:column;align-items:stretch;gap:0;padding:4px 20px 10px}.ek-nav a{min-height:48px;border-bottom:1px solid #eee8f5;font-size:14px}.ek-nav a:last-child{border-bottom:0}.ek-nav a:after{display:none}}
@media(prefers-reduced-motion:reduce){.ek-header *{scroll-behavior:auto;transition:none!important}}
</style>'''
script='''<script id="everkind-accessibility-controls">
(()=>{
  const root=document.documentElement;
  let size=0;
  try{size=Number(localStorage.getItem('everkind-text-size')||0)}catch{}
  if(!Number.isInteger(size)||size<0||size>2)size=0;
  const apply=()=>{
    root.classList.toggle('ek-text-large',size===1);
    root.classList.toggle('ek-text-larger',size===2);
    document.querySelectorAll('[data-font-scale]').forEach(button=>{
      button.setAttribute('aria-pressed',String(size>0));
      button.setAttribute('aria-label',size===2?'Reset text size':'Increase text size');
      const label=button.querySelector('.ek-a11y-label');
      if(label)label.textContent=size===0?'Text size':size===1?'Larger text':'Reset text';
      button.title=size===0?'Increase text size':size===1?'Increase text size again':'Restore default text size';
    });
  };
  apply();
  document.querySelectorAll('[data-font-scale]').forEach(button=>button.addEventListener('click',()=>{
    size=(size+1)%3;apply();
    try{localStorage.setItem('everkind-text-size',String(size))}catch{}
  }));
  const menu=document.querySelector('.ek-menu');
  const nav=document.querySelector('.ek-nav');
  if(menu&&nav)menu.addEventListener('click',()=>{
    const open=nav.classList.toggle('is-open');
    menu.setAttribute('aria-expanded',String(open));
    menu.setAttribute('aria-label',open?'Close navigation':'Open navigation');
    menu.querySelector('span').textContent=open?'×':'☰';
  });
})();
</script>'''
photos={
'assets/veranda-companionship.jpg':'https://images.pexels.com/photos/6148943/pexels-photo-6148943.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1600',
'assets/companion-sarah.jpg':'https://images.pexels.com/photos/7089170/pexels-photo-7089170.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=900',
'assets/family-story.jpg':'https://images.pexels.com/photos/15362909/pexels-photo-15362909.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1200'
}
for name in pages:
 p=out/name;s=p.read_text()
 s=re.sub(r'<header\b[^>]*>[\s\S]*?</header>',nav,s,count=1)
 # Remove the redundant label next to any repeated footer wordmark.
 s=re.sub(r'(<img\b[^>]*alt="EverKind Brand Logo"[^>]*>\s*)<span\b[^>]*>\s*EverKind\s*</span>',r'\1',s,flags=re.I)
 for old,new in photos.items():s=s.replace(old,new)
 # Add the shared header styling and persistent text-size/mobile-navigation controls.
 s=s.replace('</head>',styles+'\n</head>',1)
 s=s.replace('</body>',script+'\n</body>',1)
 p.write_text(s)
