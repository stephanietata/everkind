const dialog = document.querySelector('.booking-dialog');
const nextButton = document.querySelector('.booking-next');
const choices = [...document.querySelectorAll('.choice-card')];
const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.main-nav');
let selectedPerson = '';

document.querySelectorAll('.book-open').forEach((button) => {
  button.addEventListener('click', () => {
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else dialog.setAttribute('open', '');
  });
});

document.querySelector('.dialog-close').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', (event) => {
  if (event.target === dialog) dialog.close();
});

choices.forEach((choice) => {
  choice.addEventListener('click', () => {
    choices.forEach((item) => {
      item.classList.remove('selected');
      item.setAttribute('aria-pressed', 'false');
    });
    choice.classList.add('selected');
    choice.setAttribute('aria-pressed', 'true');
    selectedPerson = choice.dataset.choice;
    nextButton.disabled = false;
  });
});

nextButton.addEventListener('click', () => {
  document.querySelector('.selected-person').textContent = selectedPerson.toLowerCase();
  document.querySelector('.booking-content').hidden = true;
  document.querySelector('.booking-step-label').hidden = true;
  document.querySelector('.progress-track').hidden = true;
  document.querySelector('.booking-success').hidden = false;
});

document.querySelector('.reset-booking').addEventListener('click', () => {
  document.querySelector('.booking-content').hidden = false;
  document.querySelector('.booking-step-label').hidden = false;
  document.querySelector('.progress-track').hidden = false;
  document.querySelector('.booking-success').hidden = true;
  choices.forEach((choice) => {
    choice.classList.remove('selected');
    choice.setAttribute('aria-pressed', 'false');
  });
  selectedPerson = '';
  nextButton.disabled = true;
});

menuButton.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(isOpen));
  menuButton.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
});

nav.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.setAttribute('aria-label', 'Open menu');
  });
});
